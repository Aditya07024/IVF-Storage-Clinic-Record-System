import React, { useEffect, useState } from 'react';
import {
  Layers,
  Database,
  CheckCircle2,
  AlertTriangle,
  FileScan,
  Activity,
  ArrowRight,
  UserPlus,
  RotateCw,
} from 'lucide-react';
import { apiRequest, clearApiCache } from '../api/client';
import { get8StepHeatmapColor } from '../utils/heatmap';

interface DashboardProps {
  onNavigate: (tab: any, canCode?: string) => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  const [data, setData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetchDashboard();
  }, []);

  const fetchDashboard = async () => {
    try {
      setLoading(true);
      const res = await apiRequest('/api/dashboard');
      if (res.success) {
        setData(res);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to load dashboard metrics.');
    } finally {
      setLoading(false);
    }
  };

  const [refreshing, setRefreshing] = useState(false);

  const handleRefresh = async () => {
    setRefreshing(true);
    clearApiCache();
    await Promise.all([
      fetchDashboard(),
      new Promise((res) => setTimeout(res, 600)),
    ]);
    setRefreshing(false);
  };

  if (loading && !refreshing) {
    return (
      <div className="flex items-center justify-center h-full min-h-[500px]">
        <div className="flex flex-col items-center gap-3 text-emerald-600">
          <div className="w-8 h-8 border-3 border-emerald-600/30 border-t-emerald-600 rounded-full animate-spin" />
          <span className="text-sm font-medium">Loading Clinic Storage Dashboard...</span>
        </div>
      </div>
    );
  }

  if (error && !data) {
    return (
      <div className="p-6 bg-rose-50 border border-rose-200 rounded-2xl text-rose-700 text-sm flex items-center justify-between">
        <span>{error}</span>
        <button onClick={fetchDashboard} className="px-4 py-2 bg-rose-100 hover:bg-rose-200 rounded-xl text-xs font-bold text-rose-800">
          Retry
        </button>
      </div>
    );
  }

  const { summary, canStats, recentActivity } = data || { summary: {}, canStats: [], recentActivity: [] };

  return (
    <div className="p-8 space-y-8 max-w-7xl mx-auto">
      {/* Refresh Loading Banner Indicator */}
      {refreshing && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl flex items-center justify-between text-emerald-950 font-medium text-xs shadow-xs animate-in fade-in">
          <div className="flex items-center gap-2.5 font-bold">
            <span className="w-4 h-4 border-2 border-emerald-600/30 border-t-emerald-600 rounded-full animate-spin shrink-0" />
            <span>Reloading updated operational metrics & storage utilization...</span>
          </div>
          <span className="text-[10px] font-mono font-bold text-emerald-800 bg-emerald-100 px-2 py-0.5 rounded border border-emerald-300">
            REFRESHING DATA
          </span>
        </div>
      )}

      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-slate-200 pb-6">
        <div>
          <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Clinic Operational Dashboard</h1>
          <p className="text-sm text-slate-500 mt-1">Real-time IVF embryo storage utilization & staff operational status</p>
        </div>
        <div className="flex flex-wrap items-center gap-2.5">
          <button
            onClick={handleRefresh}
            disabled={refreshing}
            className="flex items-center gap-2 px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl border border-slate-300 shadow-xs transition-all active:scale-95 disabled:opacity-50"
          >
            <RotateCw className={`w-4 h-4 text-slate-700 ${refreshing ? 'animate-spin' : ''}`} />
            <span>{refreshing ? 'Refreshing...' : 'Refresh Data'}</span>
          </button>
          <button
            onClick={() => onNavigate('new-patient')}
            className="flex items-center gap-2 px-4 py-2.5 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white font-semibold text-xs rounded-xl shadow-md shadow-emerald-600/20 transition-all"
          >
            <UserPlus className="w-4 h-4" />
            <span>New Patient</span>
          </button>
          <button
            onClick={() => onNavigate('container-view')}
            className="flex items-center gap-2 px-4 py-2.5 bg-white hover:bg-slate-50 text-slate-700 font-semibold text-xs rounded-xl border border-slate-300 shadow-sm transition-all"
          >
            <Layers className="w-4 h-4 text-emerald-600" />
            <span>Container View</span>
          </button>
        </div>
      </div>

      {/* Pending OCR Alert Banner */}
      {summary.pendingOcrCount > 0 && (
        <div className="p-4 bg-amber-50 border border-amber-200 rounded-2xl flex items-center justify-between text-amber-900 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-amber-100 rounded-xl flex items-center justify-center shrink-0">
              <FileScan className="w-5 h-5 text-amber-700" />
            </div>
            <div>
              <div className="font-bold text-sm">Pending OCR Verifications ({summary.pendingOcrCount})</div>
              <div className="text-xs text-amber-800">Scanned patient records require human verification before finalizing medical record.</div>
            </div>
          </div>
          <button
            onClick={() => onNavigate('ocr')}
            className="flex items-center gap-2 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs rounded-xl transition-all shadow-sm"
          >
            <span>Review OCR</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* Top Metric Cards (2 Rows 2 Cols on Mobile) */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5">
        <div className="bg-white p-3.5 sm:p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2 sm:space-y-3">
          <div className="flex items-center justify-between text-slate-500 text-[10px] sm:text-xs font-semibold uppercase tracking-wider">
            <span>Storage Cans</span>
            <Database className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-600 shrink-0" />
          </div>
          <div className="text-xl sm:text-3xl font-bold text-slate-900 tracking-tight">{summary.totalCans} Cans</div>
          <div className="text-[11px] sm:text-xs text-slate-500">{summary.totalVisoTubes} total Viso Tubes</div>
        </div>

        <div className="bg-white p-3.5 sm:p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2 sm:space-y-3">
          <div className="flex items-center justify-between text-slate-500 text-[10px] sm:text-xs font-semibold uppercase tracking-wider">
            <span>Occupied Straws</span>
            <Layers className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-600 shrink-0" />
          </div>
          <div className="text-xl sm:text-3xl font-bold text-emerald-700 tracking-tight">{summary.occupiedStraws}</div>
          <div className="text-[11px] sm:text-xs text-slate-500">Total occupied straws</div>
        </div>

        <div className="bg-white p-3.5 sm:p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2 sm:space-y-3">
          <div className="flex items-center justify-between text-slate-500 text-[10px] sm:text-xs font-semibold uppercase tracking-wider">
            <span>Available Capacity</span>
            <CheckCircle2 className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-600 shrink-0" />
          </div>
          <div className="text-xl sm:text-3xl font-bold text-emerald-600 tracking-tight">{summary.availableStraws}</div>
          <div className="text-[11px] sm:text-xs text-slate-500">Straw slots available</div>
        </div>

        <div className="bg-white p-3.5 sm:p-5 rounded-2xl border border-slate-200 shadow-sm space-y-2 sm:space-y-3">
          <div className="flex items-center justify-between text-slate-500 text-[10px] sm:text-xs font-semibold uppercase tracking-wider">
            <span>Global Utilization</span>
            <Activity className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-emerald-600 shrink-0" />
          </div>
          <div className="text-xl sm:text-3xl font-bold text-slate-900 tracking-tight">{summary.globalUtilizationPercentage}</div>
          <div className="w-full bg-slate-100 h-2 rounded-full overflow-hidden border border-slate-200">
            <div
              className="bg-gradient-to-r from-emerald-500 to-teal-600 h-full rounded-full transition-all duration-500"
              style={{ width: summary.globalUtilizationPercentage }}
            />
          </div>
        </div>
      </div>

      {/* Storage Utilization per Can Visualization */}
      <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-sm space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Can Storage Overview</h2>
            <p className="text-xs text-slate-500">Live capacity & utilization metrics breakdown per physical Can</p>
          </div>
          <button
            onClick={() => onNavigate('container-view')}
            className="text-xs font-bold text-emerald-700 hover:text-emerald-800 flex items-center gap-1"
          >
            <span>Full Visual Container View</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {canStats.map((can: any) => {
            const step = get8StepHeatmapColor(can.utilizationPercentage || 0);
            return (
              <div
                key={can.canId}
                onClick={() => onNavigate('container-view', can.canCode)}
                className="bg-slate-50/60 p-5 rounded-2xl border border-slate-200 space-y-3 hover:border-emerald-500 hover:shadow-md cursor-pointer transition-all group relative overflow-hidden"
                title={`Click to open ${can.canCode} in Full Container View`}
              >
                <div className="flex items-center justify-between">
                  <div className="font-bold text-sm text-slate-900 group-hover:text-emerald-700 transition-colors flex items-center gap-1.5">
                    <span>{can.canCode}</span>
                    <span className="text-[10px] text-emerald-600 font-semibold opacity-0 group-hover:opacity-100 transition-opacity">View →</span>
                  </div>
                  <span
                    className={`px-2.5 py-1 rounded-full text-[11px] font-bold border ${step.bgClass}`}
                    style={{ backgroundColor: step.hex }}
                  >
                    {can.utilizationPercentage}% Occupied ({step.name})
                  </span>
                </div>

                <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden border border-slate-300">
                  <div
                    className="h-full rounded-full transition-all duration-500"
                    style={{ width: `${can.utilizationPercentage}%`, backgroundColor: step.hex }}
                  />
                </div>

                <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
                  <span>{can.occupiedStraws} / {can.maxCapacityStraws} straws</span>
                  <span className="text-slate-600 font-medium">{can.availableStraws} available</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
